<?php   
$_SESSION['order-number']=0;
/*$we = htmlspecialchars($_GET["total"]);
 header('Location: https://blueichor.org?total=$we&type=shop');*/
?>