<?php
$con = mysqli_connect("localhost","root","12345678","blueicho_try");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: ";
  }
?>
